<?php
/*
Last modified: 2012/09/19
License: GPL2
http://www.imamura.biz/blog/
*/
if (!defined('ABSPATH') && !defined('WP_UNINSTALL_PLUGIN')) {exit();}
delete_option('rcmd_opt');
?>
